submissionType = 1  # This must be included and is used to tell our code that this is an integer array submission

def predictionResults():
    # returning the predictions as hard-coded values which I copied from the csv
    return [0, 2, 2, 3, 0, 0, 4, 2, 0, 3, 3, 2, 0, 0, 2, 3, 0, 4, 2, 0, 2, 3, 0, 0, 0, 3, 0, 0, 0, 2, 3, 3, 0, 0, 2, 2, 3, 3, 0, 3, 3, 2, 0, 4, 0, 3, 3, 0, 0, 2, 0, 0, 2, 3, 3, 0, 0, 2, 0, 2, 2, 2, 7, 2, 0, 0, 0, 3, 0, 3, 3, 2, 2, 3, 4, 0, 0, 0, 0, 0, 0, 3, 0, 3, 2, 3, 3, 0, 0, 0, 0, 2, 7, 0, 4, 2, 2, 7, 0, 4, 0, 0, 2, 0, 4, 2, 0, 3, 3, 3, 0, 0, 2, 2, 7, 0, 2, 2, 0, 2, 0]